from flask import Flask
from flask_session import Session
from .config import Config
from .routes import bp as main_bp

def create_app():
    app = Flask(__name__, static_folder="static", template_folder="templates")
    app.config.from_object(Config)
    Session(app)
    app.register_blueprint(main_bp)
    return app