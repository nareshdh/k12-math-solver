import os
from dotenv import load_dotenv
load_dotenv()

def parse_bool(v, default=False):
    if v is None:
        return default
    return v.lower() in ("1","true","yes","y","on")

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me")
    MAX_CONTENT_LENGTH_MB = int(os.getenv("MAX_CONTENT_LENGTH_MB", "50"))
    MAX_CONTENT_LENGTH = MAX_CONTENT_LENGTH_MB * 1024 * 1024
    UPLOAD_FOLDER = os.getenv("UPLOAD_FOLDER", "uploads")
    SESSION_TYPE = "filesystem"
    PERMANENT_SESSION_LIFETIME = 3600

    LOG_FILES = [p.strip() for p in os.getenv("LOG_FILES","").split(",") if p.strip()] or [
        "logs/app.log", "logs/worker.log", "logs/access.log", "logs/errors.log"
    ]

    BASE_TERMINAL_DIR = os.path.abspath(os.getenv("BASE_TERMINAL_DIR", "."))
    ALLOW_COMMANDS = set([c.strip() for c in os.getenv("ALLOW_COMMANDS","ls,dir,cat,type,cd,pwd,echo,head,tail,whoami").split(",") if c.strip()])
    LOG_FILES_ABS = [os.path.abspath(p) for p in LOG_FILES]

    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

    RAW_SCRIPTS_SEQUENCE = os.getenv("SCRIPTS_SEQUENCE", "").strip()
    if RAW_SCRIPTS_SEQUENCE:
        SCRIPTS_SEQUENCE = [c.strip() for c in RAW_SCRIPTS_SEQUENCE.split(";") if c.strip()]
    else:
        SCRIPTS_SEQUENCE = []

    RAW_SCRIPTS_SEQUENCE_EXISTING = os.getenv("SCRIPTS_SEQUENCE_EXISTING", "").strip()
    if RAW_SCRIPTS_SEQUENCE_EXISTING:
        SCRIPTS_SEQUENCE_EXISTING = [c.strip() for c in RAW_SCRIPTS_SEQUENCE_EXISTING.split(";") if c.strip()]
    else:
        SCRIPTS_SEQUENCE_EXISTING = []

    try:
        SCRIPTS_TIMEOUT_SEC = int(os.getenv("SCRIPTS_TIMEOUT_SEC", "120"))
    except ValueError:
        SCRIPTS_TIMEOUT_SEC = 120

    # Analytics DB path (SQLite)
    DB_PATH = os.getenv("DB_PATH", os.path.join(os.path.dirname(os.path.dirname(__file__)), "analytics.db"))