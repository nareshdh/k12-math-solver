import os, zipfile, tempfile
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = {"zip"}

def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def process_zip(zip_path: str, work_dir: str) -> dict:
    tmp_extract = tempfile.mkdtemp(dir=work_dir, prefix="extract_")
    file_count = 0
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            for member in zf.infolist():
                member_path = os.path.normpath(os.path.join(tmp_extract, member.filename))
                if not member_path.startswith(os.path.abspath(tmp_extract)):
                    raise ValueError("Illegal file path in zip")
            zf.extractall(tmp_extract)
        for root, dirs, files in os.walk(tmp_extract):
            file_count += len(files)
        return {"status":"ok", "extracted_to": tmp_extract, "files_found": file_count}
    except zipfile.BadZipFile:
        return {"status":"error", "message":"Invalid or corrupted zip."}
    except Exception as e:
        return {"status":"error", "message": str(e)}