import os, shlex, subprocess, sqlite3
from flask import Blueprint, render_template, request, jsonify, session, current_app
from werkzeug.utils import secure_filename
from .processing import allowed_file, process_zip
from .terminal import run_command

bp = Blueprint("main", __name__)

def get_db_connection():
    db_path = current_app.config["DB_PATH"]
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

@bp.route("/", methods=["GET"])
def index():
    base_dir = current_app.config["BASE_TERMINAL_DIR"]
    if "cwd" not in session:
        session["cwd"] = os.path.abspath(base_dir)
    return render_template("index.html",
                           log_files=current_app.config["LOG_FILES"],
                           scripts_sequence=current_app.config.get("SCRIPTS_SEQUENCE", []),
                           scripts_sequence_existing=current_app.config.get("SCRIPTS_SEQUENCE_EXISTING", []))

@bp.post("/api/upload")
def upload():
    if "zipfile" not in request.files:
        return jsonify({"status":"error", "message":"No file part"}), 400
    file = request.files["zipfile"]
    if file.filename == "":
        return jsonify({"status":"error", "message":"No selected file"}), 400
    if not allowed_file(file.filename):
        return jsonify({"status":"error", "message":"Only .zip files allowed"}), 400
    filename = secure_filename(file.filename)
    upload_dir = current_app.config["UPLOAD_FOLDER"]
    os.makedirs(upload_dir, exist_ok=True)
    save_path = os.path.join(upload_dir, filename)
    file.save(save_path)

    result = process_zip(save_path, upload_dir)
    if isinstance(result, dict) and result.get("status") == "ok":
        session["last_extract"] = result.get("extracted_to")
    return jsonify(result)

@bp.post("/api/terminal/exec")
def terminal_exec():
    data = request.get_json(silent=True) or {}
    cmd = data.get("cmd", "").strip()
    if not cmd:
        return jsonify({"status":"error", "message":"No command provided"}), 400
    base_dir = current_app.config["BASE_TERMINAL_DIR"]
    cwd = session.get("cwd", os.path.abspath(base_dir))
    allow = current_app.config["ALLOW_COMMANDS"]
    code, out = run_command(cmd, cwd, allow, base_dir)
    if code == 200:
        session["cwd"] = out
        return jsonify({"status":"ok", "cwd": session["cwd"], "output": ""})
    status = "ok" if code == 0 else "error"
    return jsonify({"status": status, "cwd": cwd, "output": out})

def _tail_file(path: str, lines: int = 200) -> str:
    line_sep = b"\n"
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            data = b""
            nl_count = 0
            while size > 0 and nl_count <= lines:
                step = min(1024, size)
                f.seek(-step, os.SEEK_CUR)
                chunk = f.read(step)
                f.seek(-step, os.SEEK_CUR)
                data = chunk + data
                nl_count = data.count(line_sep)
                size -= step
        text = data.decode(errors="replace")
        if nl_count > lines:
            text = "\n".join(text.splitlines()[-lines:])
        return text
    except FileNotFoundError:
        return "Log file not found."
    except Exception as e:
        return f"Error reading log: {e}"

@bp.get("/api/log/<int:idx>")
def get_log(idx: int):
    files = current_app.config["LOG_FILES_ABS"]
    if idx < 0 or idx >= len(files):
        return jsonify({"status":"error", "message":"Invalid log index"}), 400
    content = _tail_file(files[idx], 400)
    return jsonify({"status":"ok", "content": content})

@bp.post("/api/scripts/run")
def run_scripts():
    data = request.get_json(silent=True) or {}
    base_dir = current_app.config["BASE_TERMINAL_DIR"]
    work_dir = session.get("last_extract", base_dir)
    if not os.path.isdir(work_dir):
        return jsonify({"status":"error", "message":f"Working directory not found: {work_dir}"}), 400

    profile = (data.get("profile") or "new").strip().lower()
    cmds = data.get("commands")
    if isinstance(cmds, list) and cmds:
        sequence = [str(c).strip() for c in cmds if str(c).strip()]
    else:
        if profile == "existing":
            sequence = list(current_app.config.get("SCRIPTS_SEQUENCE_EXISTING", []))
        else:
            sequence = list(current_app.config.get("SCRIPTS_SEQUENCE", []))

    if not sequence:
        return jsonify({"status":"error", "message":"No scripts configured for profile: " + profile}), 400

    timeout = int(current_app.config.get("SCRIPTS_TIMEOUT_SEC", 120))
    results = []
    overall_ok = True
    for cmd in sequence:
        try:
            parts = shlex.split(cmd)
        except Exception as e:
            results.append({"cmd": cmd, "returncode": 1, "output": f"Parse error: {e}"})
            overall_ok = False
            continue
        try:
            proc = subprocess.run(parts, cwd=work_dir, text=True, capture_output=True, timeout=timeout)
            output = (proc.stdout or "") + (proc.stderr or "")
            rc = proc.returncode
            results.append({"cmd": cmd, "returncode": rc, "output": output})
            if rc != 0:
                overall_ok = False
        except subprocess.TimeoutExpired:
            results.append({"cmd": cmd, "returncode": 124, "output": f"Timed out after {timeout}s"})
            overall_ok = False
        except Exception as e:
            results.append({"cmd": cmd, "returncode": 1, "output": str(e)})
            overall_ok = False

    return jsonify({"status": "ok" if overall_ok else "error", "work_dir": work_dir, "results": results})

# ---- Analytics endpoints ----

@bp.get("/api/analytics/params")
def analytics_params():
    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT DISTINCT input FROM algo_output ORDER BY input")
        inputs = [row[0] for row in cur.fetchall()]
        cur.execute("SELECT DISTINCT output FROM algo_output ORDER BY output")
        outputs = [row[0] for row in cur.fetchall()]
        conn.close()
        return jsonify({"status": "ok", "inputs": inputs, "outputs": outputs})
    except Exception as e:
        return jsonify({"status":"error", "message": str(e)}), 500

@bp.post("/api/analytics/data")
def analytics_data():
    data = request.get_json(silent=True) or {}
    input_param = data.get("input_param")
    output_param = data.get("output_param")
    if not input_param or not output_param:
        return jsonify({"status":"error", "message":"Both input_param and output_param are required"}), 400

    try:
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "SELECT input_value, output_value FROM algo_output WHERE input=? AND output=? ORDER BY row_id",
            (input_param, output_param),
        )
        rows = cur.fetchall()
        conn.close()

        points = [{"x": r[0], "y": r[1]} for r in rows]
        return jsonify({"status":"ok", "points": points})
    except Exception as e:
        return jsonify({"status":"error", "message": str(e)}), 500