import os, re, shlex, subprocess
from typing import Tuple

FORBIDDEN_RE = re.compile(r"(\|\|)|(&&)|[|;&<>`$()]")

def resolve_path(base_dir: str, current_dir: str, target: str) -> str:
    new_path = os.path.abspath(os.path.normpath(os.path.join(current_dir, target)))
    base_dir_abs = os.path.abspath(base_dir)
    if not new_path.startswith(base_dir_abs):
        raise PermissionError("Path escapes sandbox root.")
    return new_path

def run_command(cmd: str, cwd: str, allow: set, base_dir: str) -> Tuple[int, str]:
    if FORBIDDEN_RE.search(cmd):
        return 1, "Disallowed meta-characters."
    try:
        parts = shlex.split(cmd)
    except Exception as e:
        return 1, f"Parse error: {e}"
    if not parts:
        return 0, ""

    command = parts[0].lower()
    if command not in allow:
        return 1, f"Command '{command}' not allowed."

    if command == "cd":
        target = parts[1] if len(parts) > 1 else base_dir
        try:
            new_dir = resolve_path(base_dir, cwd, target)
            if not os.path.isdir(new_dir):
                return 1, f"No such directory: {target}"
            return 200, new_dir
        except Exception as e:
            return 1, str(e)

    if command == "ls":
        mapped = ["cmd.exe", "/c", "dir"] if os.name == "nt" else ["ls"] + parts[1:]
    elif command == "dir":
        mapped = ["cmd.exe", "/c", "dir"] if os.name == "nt" else ["ls"] + parts[1:]
    elif command == "type" and os.name != "nt":
        mapped = ["cat"] + parts[1:]
    elif command == "cat" and os.name == "nt":
        mapped = ["cmd.exe", "/c", "type"] + parts[1:]
    else:
        mapped = parts

    try:
        proc = subprocess.run(mapped, cwd=cwd, capture_output=True, text=True, timeout=8)
        out = (proc.stdout or "") + (proc.stderr or "")
        return proc.returncode, out if out else "(no output)"
    except subprocess.TimeoutExpired:
        return 1, "Command timed out."
    except Exception as e:
        return 1, str(e)