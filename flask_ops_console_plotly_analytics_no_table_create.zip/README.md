# Flask Ops Console with Plotly Analytics

Features:
- New Zip: upload zip, sandbox terminal, run configured script sequence, log tabs.
- Existing Zips: run a secondary script sequence.
- Analytics: select input/output parameters backed by an SQLite table `algo_output`
  and plot input_value vs output_value using Plotly.

## DB Schema (expected)

The application assumes a pre-existing SQLite table named `algo_output` with the following columns:

Table: `algo_output`

- row_id (INTEGER PRIMARY KEY or similar)
- input (TEXT)
- output (TEXT)
- input_value (REAL)
- output_value (REAL)

## Quickstart

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # adjust paths, secrets, etc.
export FLASK_APP=run.py

# Create analytics.db and algo_output as needed:
python -c "import sqlite3; db=sqlite3.connect('analytics.db'); db.execute('algo_output (row_id INTEGER PRIMARY KEY, input TEXT, output TEXT, input_value REAL, output_value REAL)'); db.commit(); db.close()"

flask run
# or: gunicorn -w 2 -b 0.0.0.0:8000 wsgi:app
```